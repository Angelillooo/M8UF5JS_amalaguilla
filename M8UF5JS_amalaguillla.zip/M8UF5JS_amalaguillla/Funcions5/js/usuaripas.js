function validaci() {
    if (document.getElementById('usr').value == 'Ibai') {
        if (document.getElementById('psw').value == '1234') {
            if (document.getElementById('rpsw').value == document.getElementById('psw').value) {
                alert ("Dades correctes");
            }
            else {
                alert ("Error");
            }
        }
        else {
            alert ("Error");
        }
    }
    else {
        alert ("Error");
    }
}