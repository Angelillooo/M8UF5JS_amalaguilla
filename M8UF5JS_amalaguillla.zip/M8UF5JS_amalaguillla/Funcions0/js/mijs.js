function apretat() {
    alert('Has fet click');
}
function suma(x,y) {
    alert(x+y);
}