function trencar(un_element){
    un_element.src = "Img/llumbreak.gif";
}
function encender(un_element){
    un_element.src = "Img/llumon.gif";
}
function apagar(un_element){
    un_element.src = "Img/llumoff.gif";
}

window.addEventListener("keydown", ences1, false);
window.addEventListener("keydown", ences2, false);
window.addEventListener("keydown", ences3, false);
window.addEventListener("keyup", apagat1, false);
window.addEventListener("keyup", apagat2, false);
window.addEventListener("keyup", apagat3, false);

function ences1(on){
    if (on.keyCode == 49){
    document.getElementById("bombeta1").src = "Img/llumon.gif";
    document.getElementById("text1").innerHTML = "1";
    }
}
function ences2(on){
    if (on.keyCode == 50){
    document.getElementById("bombeta2").src = "Img/llumon.gif"
    document.getElementById("text2").innerHTML = "2";
    }
}
function ences3(on){
    if (on.keyCode == 51){
    document.getElementById("bombeta3").src = "Img/llumon.gif"
    document.getElementById("text3").innerHTML = "3";
    }
}
function apagat1(off){
    if (off.keyCode == 49){
    document.getElementById("bombeta1").src = "Img/llumoff.gif"
    document.getElementById("text1").innerHTML = "";
    }
}
function apagat2(off){
    if (off.keyCode == 50){
    document.getElementById("bombeta2").src = "Img/llumoff.gif"
    document.getElementById("text2").innerHTML = "";
    }
}
function apagat3(off){
    if (off.keyCode == 51){
    document.getElementById("bombeta3").src = "Img/llumoff.gif"
    document.getElementById("text3").innerHTML = "";    
    }
}