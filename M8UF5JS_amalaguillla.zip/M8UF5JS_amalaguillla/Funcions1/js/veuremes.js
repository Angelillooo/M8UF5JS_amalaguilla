function veureMes(){
    document.getElementById("mestext").classList.add('visible');
}