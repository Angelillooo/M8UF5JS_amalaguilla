function validacio() {
    if (document.getElementById('usr').value == 'Ibai') {
        if (document.getElementById('psw').value == '1234') {
            if (document.getElementById('rpsw').value == document.getElementById('psw').value) {
                alert ("Dades correctes");
            }
            else {
                alert ("Error");
            }
        }
        else {
            alert ("Error");
        }
    }
    else {
        alert ("Error");
    }
}
function guardar() {
    var nom = document.getElementById('nom').value;
    var cnom = document.getElementById('cnom').value;

    localStorage.setItem("nom",nom);
    localStorage.setItem("cnom",cnom);
}
function recuperar() {
    localStorage.getItem("nom");
    localStorage.getItem("cnom");
    console.log(localStorage.getItem("nom")+"***"+localStorage.getItem("cnom"));
}
function esborrar() {
    localStorage.removeItem("nom");
    localStorage.removeItem("cnom");
}