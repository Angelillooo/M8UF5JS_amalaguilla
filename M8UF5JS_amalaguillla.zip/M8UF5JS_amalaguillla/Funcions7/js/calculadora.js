function afegir(numero){
    document.getElementById("final").value += numero
}
function borrar(){
    document.getElementById("final").value = ""
}
function igual(){
    document.getElementById("final").value = eval(document.getElementById("final").value)
}